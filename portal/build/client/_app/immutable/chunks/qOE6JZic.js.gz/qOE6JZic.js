import{J as t}from"./CHlqn90R.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
